package screenshot;

import java.io.File;
import java.io.IOException;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

import io.github.bonigarcia.wdm.WebDriverManager;

public class ScreenshotDemo {

	public static void main(String[] args) throws IOException, InterruptedException {
		// TODO Auto-generated method stub
		System.setProperty("webdriver.chrome.driver", "src\\test\\resources\\driver\\chromedriver.exe");
		WebDriver driver = new ChromeDriver();

		driver.get("https://opensource-demo.orangehrmlive.com/web/index.php/auth/login");
		driver.manage().window().maximize();
		Thread.sleep(2000);
		TakesScreenshot ts = (TakesScreenshot) driver;
		File src = ts.getScreenshotAs(OutputType.FILE);
		File trg = new File("C:\\Users\\mopullag\\eclipse-workspace\\chitti\\CucumberSeleniumProject\\src\\test\\java\\screenshot\\OrangeHrm.png");
		FileUtils.copyFile(src, trg);
		// single element
		WebElement featureproducts = driver.findElement(By.name("username"));
		File src2 = featureproducts.getScreenshotAs(OutputType.FILE);
		File trgt = new File(
				"C:\\Users\\mopullag\\eclipse-workspace\\chitti\\CucumberSeleniumProject\\src\\test\\java\\screenshot\\username.png");
		FileUtils.copyFile(src2, trgt);

	}

}
