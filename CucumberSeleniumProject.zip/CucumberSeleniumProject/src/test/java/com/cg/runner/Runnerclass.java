package com.cg.runner;

import io.cucumber.testng.AbstractTestNGCucumberTests;
import io.cucumber.testng.CucumberOptions;
 
@CucumberOptions(features="src\\test\\resources\\FeatureFiles",glue= {"com\\cg\\stepdefinition"}, monochrome=true,
plugin={"pretty","html:report/htmlreport/myreport1.html","json:report/jsonreport/myreport2.json","junit:report/xmlreport/myreport3.xml",
		"com.aventstack.extentreports.cucumber.adapter.ExtentCucumberAdapter:"
})
public class Runnerclass extends AbstractTestNGCucumberTests{
}