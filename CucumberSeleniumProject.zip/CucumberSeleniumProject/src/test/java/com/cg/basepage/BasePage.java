package com.cg.basepage;

import org.openqa.selenium.WebDriver;


import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.Test;
public class BasePage {
	public static WebDriver driver;
	public  BasePage() {
		driver = new ChromeDriver();
		//System.out.println("Driver initialized");
	}
	@Test
	public void loadUrl() {
		driver.get("https://opensource-demo.orangehrmlive.com/web/index.php/auth/login");
		driver.manage().window().maximize();
	}
	public WebDriver returndriver() {
		// TODO Auto-generated method stub
		return driver;
	}
}

