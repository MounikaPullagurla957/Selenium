package com.cg.pagefactory;

import java.time.Duration;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class ClaimRequestPage {

	WebDriver driver;
	
	@FindBy(xpath = "//input[@placeholder='Username']")
	WebElement txt_username;
	@FindBy(css = "input[placeholder='Password']")
	WebElement txt_password;
	@FindBy(xpath = "//button[normalize-space()='Login']")
	WebElement btn_submit;
	@FindBy(xpath="//span[text()='Claim']")
	WebElement claim;
	@FindBy(xpath="//a[text()='Assign Claim']")
	WebElement assignclaim;
	@FindBy(css="input[placeholder='Type for hints...']")
	WebElement employeeName;
	@FindBy(css="div[role='option']")
	WebElement selectname;
	@FindBy(xpath="(//div[text()='-- Select --'])[1]")
	WebElement select;
	@FindBy(xpath="//span[text()='Medical Reimbursement']")
	WebElement option;
	@FindBy(xpath="(//div[@class='oxd-select-text--after'])[2]")
	WebElement select2;
	@FindBy(xpath="//span[text()='Indian Rupee']")
	WebElement option2;
	@FindBy(css="textarea[class*='oxd-textarea']")
	WebElement remarks;
	@FindBy(css="button[type='submit']")
	WebElement create;
	
	public ClaimRequestPage(WebDriver driver) {
		this.driver=driver;
		PageFactory.initElements(driver, this);
	}
	public void login(String username, String password) {
		txt_username.sendKeys(username);
		txt_password.sendKeys(password);
	}

	public void Clicksubmit()throws InterruptedException  {
		btn_submit.click();
		Thread.sleep(1000);
		
		claim.click();
	}
	
	public void navigation() {
		
		assignclaim.click();
		
		
	}
	public void empdetails(String EMPName) throws InterruptedException {
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(60));	
		employeeName.sendKeys(EMPName);
		Thread.sleep(2000);
		selectname.click();
		select.click();
		option.click();
	}
	public void empdetails2() throws InterruptedException {
		Thread.sleep(3000);
		select2.click();
		option2.click();
		Thread.sleep(2000);
	}
	public void remarknote(String note) {		
		remarks.sendKeys(note);
	}
	public void Creation() throws InterruptedException {
		Thread.sleep(2000);
		create.click();
	}

 
}


