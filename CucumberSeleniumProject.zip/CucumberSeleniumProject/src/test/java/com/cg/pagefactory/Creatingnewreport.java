package com.cg.pagefactory;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class Creatingnewreport {
	WebDriver driver;
	public Creatingnewreport  (WebDriver driver) {
		this.driver=driver;
		PageFactory.initElements(driver, this);
	}
	@FindBy(xpath = "//input[@placeholder='Username']")
	WebElement txtUserName;
	@FindBy(xpath = "//input[@placeholder='Password']")
	WebElement txtPassword;
	@FindBy(xpath = "//button[@type='submit']")
	WebElement btnLogin;
	@FindBy(xpath = "//a[normalization-space()='PIM']")
	WebElement option_PIM;
	@FindBy(xpath = "//a[normalize-space()='Reports']")
	WebElement option_reports;
	@FindBy(xpath = "//button[normalize-space()='Add']")
	WebElement button_add;
	@FindBy(xpath = "//input[@placeholder='Type here ...']")
	WebElement txt_reportname;
	@FindBy(xpath = "//button[normalize-space()='Save']")
	WebElement button_save;
	public void Login() {
		txtUserName.sendKeys("Admin");
		txtPassword.sendKeys("admin123");
		btnLogin.click();
	}

	public void pim()
	{
		option_PIM.click();
	}
	public void addReport()
	{
		txt_reportname.click();
		
	}
	public void enterReportName() {
		txt_reportname.sendKeys("Internet expenses");
	}
	public void clickOnSave() {
		button_save.click();
	}
	


}
