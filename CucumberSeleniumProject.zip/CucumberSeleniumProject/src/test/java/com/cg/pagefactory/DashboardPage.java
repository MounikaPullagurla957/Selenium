package com.cg.pagefactory;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class DashboardPage {
	WebDriver driver;
	public DashboardPage (WebDriver driver) {
		this.driver=driver;
		PageFactory.initElements(driver, this);
	}
	@FindBy(xpath = "//input[@placeholder='Username']")
	WebElement txtUserName;
	@FindBy(xpath = "//input[@placeholder='Password']")
	WebElement txtPassword;
	@FindBy(xpath = "//button[@type='submit']")
	WebElement btnLogin;
	@FindBy(xpath = "//body[1]/div[1]/div[1]/div[2]/div[2]/div[1]/div[1]/div[1]")
	WebElement timeatwork;

	@FindBy(xpath = "//body[1]/div[1]/div[1]/div[2]/div[2]/div[1]/div[2]/div[1]")
	WebElement myactions;

	@FindBy(xpath = "//body[1]/div[1]/div[1]/div[2]/div[2]/div[1]/div[3]/div[1]")
	WebElement quicklaunch;

	@FindBy(xpath = "//body[1]/div[1]/div[1]/div[2]/div[2]/div[1]/div[4]/div[1]")
	WebElement buzzlatestposts;

	@FindBy(xpath = "//div[@class='oxd-sheet oxd-sheet--rounded oxd-sheet--white orangehrm-dashboard-widget emp-leave-chart']")
	WebElement employeesonleavetoday;

	@FindBy(xpath = "//body[1]/div[1]/div[1]/div[2]/div[2]/div[1]/div[6]/div[1]")
	WebElement employeedistributionbysubunit;

	@FindBy(xpath = "//body[1]/div[1]/div[1]/div[2]/div[2]/div[1]/div[7]/div[1]")
	WebElement employeedistributionbylocation;

	public void Login() {
		txtUserName.sendKeys("Admin");
		txtPassword.sendKeys("admin123");
		btnLogin.click();
	}
	public void timeatwork() {
		timeatwork.isDisplayed();
	}

	public void myactions() {
		myactions.isDisplayed();
	}

	public void quicklaunch() {
		System.out.println(quicklaunch.isDisplayed());
	}

	public void buzzlatestposts() {
		System.out.println(buzzlatestposts.isDisplayed());
	}

	public void employeesonleavetoday() {
		System.out.println(employeesonleavetoday.isDisplayed());
	}

	public void employeedistributionbysubunit() {
		System.out.println(employeedistributionbysubunit.isDisplayed());
	}

	public void employeedistributionbylocation() {
		System.out.println(employeedistributionbylocation.isDisplayed());
	}
	

}
