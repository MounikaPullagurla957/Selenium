package com.cg.pagefactory;

import java.time.Duration;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class AddEmployee {
	WebDriver driver;

	public AddEmployee(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}

	@FindBy(name="username")
	WebElement txt_username;	
	@FindBy(css = "input[placeholder='Password']")
	WebElement txt_password;
	@FindBy(xpath = "//button[normalize-space()='Login']")
	WebElement btn_submit;
	@FindBy(xpath = "//span[normalize-space()='PIM']")
	WebElement pim;
	@FindBy(xpath = "//a[normalize-space()='Add Employee']")
	WebElement addemp1;
	@FindBy(name = "firstName")
	WebElement fname;
	@FindBy(css = "input[placeholder='Middle Name']")
	WebElement mname;
	@FindBy(xpath = "//input[@placeholder='Last Name']")
	WebElement lname;
	@FindBy(xpath = "//div[@class='oxd-input-group oxd-input-field-bottom-space']//div//input[@class='oxd-input oxd-input--active']")
	WebElement empid;
	@FindBy(xpath = "//span[@class='oxd-switch-input oxd-switch-input--active --label-right']")
	WebElement enable_login;
	@FindBy(css = "body > div:nth-child(3) > div:nth-child(1) > div:nth-child(2) > div:nth-child(2) > div:nth-child(1) > div:nth-child(1) > form:nth-child(3) > div:nth-child(1) > div:nth-child(2) > div:nth-child(4) > div:nth-child(1) > div:nth-child(1) > div:nth-child(1) > div:nth-child(2)")
	WebElement username;
	@FindBy(xpath = "//div[@class='oxd-grid-item oxd-grid-item--gutters user-password-cell']//div[@class='oxd-input-group oxd-input-field-bottom-space']//div//input[@type='password']")
	WebElement password;
	@FindBy(xpath = "//div[@class='oxd-grid-item oxd-grid-item--gutters']//div[@class='oxd-input-group oxd-input-field-bottom-space']//div//input[@type='password']")
	WebElement confpassword;
	@FindBy(xpath = "//button[@type='submit']")
	WebElement save_btn;

	public void login(String username, String password) throws InterruptedException {
		txt_username.sendKeys(username);
		txt_password.sendKeys(password);
		btn_submit.click();
		Thread.sleep(1000);
		pim.click();
	}

	public void clickAdd() throws InterruptedException  {
		Thread.sleep(1000);
		addemp1.click();

	}

	public void addempdetails() {
		fname.sendKeys("mounika");
		mname.sendKeys("Pullagurla");
		lname.sendKeys("Reddy");

	}

	public void Enablelogin() {
		enable_login.click();
	}

	public void Login() {
		username.sendKeys("Mouni");
		password.sendKeys("Mouni@123");
		confpassword.sendKeys("Mouni@123");
	}

	public void Savebtn() {
		save_btn.click();
	}

}
