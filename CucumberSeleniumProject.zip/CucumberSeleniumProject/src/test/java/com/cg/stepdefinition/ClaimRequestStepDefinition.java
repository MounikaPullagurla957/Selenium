package com.cg.stepdefinition;

import java.time.Duration;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import com.cg.pagefactory.ClaimRequestPage;


import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import io.github.bonigarcia.wdm.WebDriverManager;

public class ClaimRequestStepDefinition {
	WebDriver driver;
	
	@Given("the user enters valid credentials with username {string} and password {string}")
	public void the_user_enters_valid_credentials_with_username_and_password(String user, String pass) throws InterruptedException {
		//WebDriverManager.chromedriver().setup();
		System.setProperty("webdriver.chrome.driver", "src\\test\\resources\\driver\\chromedriver.exe");
		  WebDriver driver=new ChromeDriver();
		  driver.manage().window().maximize();
		  driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(1000));
		  driver.get("https://opensource-demo.orangehrmlive.com/web/index.php/auth/login");	
		  ClaimRequestPage crp=new ClaimRequestPage(driver);
		  crp.login(user, pass);
		  crp.Clicksubmit();
		  crp.navigation();
		  
		  
	}

	@When("User navigates to the Claim section")
	public void user_navigates_to_the_claim_section() throws InterruptedException {
		Thread.sleep(2000);
		System.out.println("User navigates to the Claim section");
		
		
		
	   
	}

	@When("User inputs Employee Name {string}")
	public void user_inputs_employee_name(String emp) throws InterruptedException {
		ClaimRequestPage crp=new ClaimRequestPage(driver);
		crp.empdetails(emp);   
	}

	@When("User selects Event Name Medical Reimbursement")
	public void user_selects_event_name_medical_reimbursement() throws InterruptedException {
		ClaimRequestPage crp=new ClaimRequestPage(driver);
		crp.empdetails2();
	   
	}

	@When("User selects Currency Indian Rupee")
	public void user_selects_currency_indian_rupee() {
		System.out.println("User sucessfully Selected indin rupee");
	    
	}

	@When("User inserts remarks if necessary {string}")
	public void user_inserts_remarks_if_necessary(String note) {
		ClaimRequestPage crp=new ClaimRequestPage(driver);
		crp.remarknote(note);
	}

	@When("User clicks on the Submit button")
	public void user_clicks_on_the_submit_button() throws InterruptedException {
		ClaimRequestPage crp=new ClaimRequestPage(driver);
		crp.Creation();

	   
	}

	@Then("System should promptly display the created claim")
	public void system_should_promptly_display_the_created_claim() throws InterruptedException {
		Thread.sleep(2000);
		driver.quit();
	    
	}




}
