package com.cg.stepdefinition;

import java.time.Duration;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import com.cg.pagefactory.DashboardPage;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class DashboardSteDefinition {
	WebDriver driver;

@Given("the user navigates to login page and user enters username and password and clicks on the Login button")
public void the_user_navigates_to_login_page_and_user_enters_username_and_password_and_clicks_on_the_login_button() {
	System.setProperty("webdriver.chrome.driver", "src\\test\\resources\\driver\\chromedriver.exe");
	  WebDriver driver=new ChromeDriver();
	  driver.manage().window().maximize();
	  driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(1000));
	  driver.get("https://opensource-demo.orangehrmlive.com/web/index.php/auth/login");	
	  DashboardPage dp=new  DashboardPage(driver);
	  dp.Login();
}

@Then("User navigates the  Dashboard page of OrangeHRM")
public void user_navigates_the_dashboard_page_of_orange_hrm() {
	System.out.println("User on Dashboard");
   
}

@When("Checking the components in Dashboard section")
public void checking_the_components_in_dashboard_section() {
	  DashboardPage dp=new  DashboardPage(driver);
	try {
		Thread.sleep(5000);
	} catch (InterruptedException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	
	dp.timeatwork();
	dp.myactions();
	dp.quicklaunch();
	dp.buzzlatestposts();
	dp.employeesonleavetoday();
	dp.employeedistributionbysubunit();
	dp.employeedistributionbylocation();
}
   


@Then("Checking components successful")
public void checking_components_successful() {
	System.out.println("Validation Completed");
	if(driver!=null)
	driver.close();
    }



}
