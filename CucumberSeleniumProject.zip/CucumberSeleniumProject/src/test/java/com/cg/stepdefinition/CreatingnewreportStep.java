package com.cg.stepdefinition;

import java.time.Duration;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import com.cg.pagefactory.Creatingnewreport;
import com.cg.pagefactory.DashboardPage;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class CreatingnewreportStep {
	WebDriver driver;
    Creatingnewreport creatingnewreport;
	
	@Given("User on the PIM Section and creating a new report")
	public void user_on_the_pim_section_and_creating_a_new_report() throws InterruptedException {
		System.setProperty("webdriver.chrome.driver", "src\\test\\resources\\driver\\chromedriver.exe");
		  WebDriver driver=new ChromeDriver();
		  driver.manage().window().maximize();
		  driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(1000));
		  driver.get("https://opensource-demo.orangehrmlive.com/web/index.php/auth/login");	
		 Creatingnewreport creatingnewreport=new Creatingnewreport(driver);
		 creatingnewreport.Login();
		 Thread.sleep(1000);
		  creatingnewreport.pim();
		  
	   
	}

	@When("User clicked on the Reports option")
	public void user_clicked_on_the_reports_option() {
    Creatingnewreport creatingnewreport=new Creatingnewreport(driver);
   
    creatingnewreport.addReport();
	}

	@When("User entered the Report name")
	public void user_entered_the_report_name() {
	    Creatingnewreport creatingnewreport=new Creatingnewreport(driver);
	    creatingnewreport.addReport();
	    creatingnewreport.enterReportName();
		
	   
	}

	@Then("User click on save button")
	public void user_click_on_save_button() {
		 Creatingnewreport creatingnewreport=new Creatingnewreport(driver);
		    creatingnewreport.clickOnSave();
		    if(driver!=null)
		    driver.close();
	   
	}



}
