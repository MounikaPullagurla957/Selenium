package com.cg.stepdefinition;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import com.cg.pagefactory.AddEmployee;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class AddEmployeeStep {
	WebDriver driver;
	AddEmployee addemployee;
	@Given("the user enters valid credentials with username {string} and password {string}    When User navigates to the PIM section")
	public void the_user_enters_valid_credentials_with_username_and_password_when_user_navigates_to_the_pim_section(String username, String password) throws InterruptedException {
	   	System.setProperty("webdriver.chrome.driver", "src\\test\\resources\\driver\\chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		driver.manage().window().maximize();
		driver.get("https://opensource-demo.orangehrmlive.com/web/index.php/auth/login");
		Thread.sleep(2000);
	    addemployee=new AddEmployee(driver);
	    addemployee.login(username,password);
	    
	}

	@When("User navigates to the PIM section")
	public void user_navigates_to_the_pim_section() throws InterruptedException {
		 addemployee=new AddEmployee(driver);
		
		
	}

	@Given("User clicks on the Add Employee button")
	public void user_clicks_on_the_add_employee_button() throws InterruptedException {
		addemployee=new AddEmployee(driver);
		 addemployee.clickAdd();
		
			   
	}

	@When("User enters employee details \\(first name, middle name, last name, employee ID)")
	public void user_enters_employee_details_first_name_middle_name_last_name_employee_id() {
	   addemployee.addempdetails();
	}

	@When("User enables login creation")
	public void user_enables_login_creation() {
	    addemployee.Enablelogin();
	}

	@When("User enters username and password")
	public void user_enters_username_and_password() {
		 addemployee.Login();
	}

	@Then("System should display the newly added employee details")
	public void system_should_display_the_newly_added_employee_details() {
		 addemployee.Savebtn();
		 driver.quit();
	    
	}


}
