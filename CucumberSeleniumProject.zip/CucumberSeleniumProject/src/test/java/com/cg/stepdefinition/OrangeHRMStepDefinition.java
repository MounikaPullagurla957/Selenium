package com.cg.stepdefinition;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import com.cg.pagefactory.OrangeHrmLoginPage;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import io.github.bonigarcia.wdm.WebDriverManager;

public class OrangeHRMStepDefinition {
	WebDriver driver;
	OrangeHrmLoginPage loginpage;

	@Given("the user is on the OrangeHRM login page")
	public void the_user_is_on_the_orange_hrm_login_page() throws InterruptedException {
		// WebDriverManager.chromedriver().setup();
		System.setProperty("webdriver.chrome.driver", "src\\test\\resources\\driver\\chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		driver.manage().window().maximize();
		driver.get("https://opensource-demo.orangehrmlive.com/web/index.php/auth/login");
		loginpage = new OrangeHrmLoginPage(driver);
		Thread.sleep(5000);

	}

	@When("the user enters valid credentials \\(username: {string}, password: {string})")
	public void the_user_enters_valid_credentials_username_password(String username, String password) {
		loginpage.login(username, password);

	}

	@When("the user clicks on the Login button")
	public void the_user_clicks_on_the_login_button() {
		loginpage.Clicksubmit();
	}

	@Then("the user should be redirected to the OrangeHRM homepage")
	public void the_user_should_be_redirected_to_the_orange_hrm_homepage() throws InterruptedException {
		if(driver!=null)
	
	     driver.quit();

	  
	
	}

}
